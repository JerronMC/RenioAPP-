package com.renio.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(11, 17, 24);
    private static final int PANEL = Color.rgb(18, 28, 39);
    private static final int PANEL_2 = Color.rgb(23, 35, 48);
    private static final int TEXT = Color.rgb(239, 246, 250);
    private static final int MUTED = Color.rgb(142, 160, 174);
    private static final int ACCENT = Color.rgb(81, 216, 208);
    private static final int LINE = Color.rgb(38, 54, 68);
    private static final int BLUE = Color.rgb(93, 161, 255);

    private SharedPreferences prefs;
    private String username = "";
    private LinearLayout root;
    private final HashMap<String, ArrayList<String>> messages = new HashMap<>();
    private final ArrayList<String> recentFiles = new ArrayList<>();
    private String activeChat = "";
    private String activeTab = "chats";
    private EditText messageInput;
    private TextView messageList;
    private ScrollView messageScroll;
    private Uri lastPickedUri;

    private static class ChatItem {
        final String name;
        final String preview;
        final String time;
        final String initials;
        ChatItem(String name, String preview, String time) {
            this.name = name;
            this.preview = preview;
            this.time = time;
            this.initials = initials(name);
        }
    }

    private final ChatItem[] demoChats = new ChatItem[] {
        new ChatItem("Mika Santos", "Sent you a photo", "now"),
        new ChatItem("Renio Updates", "Welcome to Renio!", "9:42"),
        new ChatItem("Kai", "That sounds good 👍", "Yesterday"),
        new ChatItem("Study Circle", "You: see you later", "Tue")
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("renio_local", MODE_PRIVATE);
        username = prefs.getString("username", "");
        if (username.isEmpty()) showLogin(); else showHome("chats");
        handleIncomingLink(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingLink(intent);
    }

    private void handleIncomingLink(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return;
        Uri uri = intent.getData();
        if (uri == null || !"renio".equals(uri.getScheme())) return;
        String host = uri.getHost() == null ? "" : uri.getHost();
        if ("share".equals(host)) {
            String incoming = uri.getQueryParameter("text");
            if (incoming != null && !incoming.trim().isEmpty()) {
                new AlertDialog.Builder(this)
                    .setTitle("Shared with you")
                    .setMessage(incoming)
                    .setPositiveButton("Got it", (d, w) -> { })
                    .show();
            } else toast("Renio share link opened");
        } else if ("profile".equals(host)) {
            String profileName = uri.getLastPathSegment();
            toast(profileName == null ? "Renio profile link opened" : "Profile link: @" + profileName);
        } else if ("invite".equals(host)) {
            toast("Renio invite link opened");
        } else {
            toast("Renio link opened");
        }
    }

    private void showLogin() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(26), dp(36), dp(26), dp(28));
        root.setBackgroundColor(BG);

        TextView brand = text("R", 29, BG, true);
        brand.setGravity(Gravity.CENTER);
        brand.setBackground(circle(ACCENT));
        add(root, brand, 64, 64);
        TextView title = text("Renio", 34, TEXT, true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(18);
        root.addView(title, titleLp);
        TextView subtitle = text("Your space. Your people.", 15, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, params(-1, -2, 0, 5, 0, 0));

        LinearLayout form = cardColumn();
        LinearLayout.LayoutParams formLp = new LinearLayout.LayoutParams(-1, -2);
        formLp.topMargin = dp(42);
        root.addView(form, formLp);
        addText(form, "Get started", 20, TEXT, true, 0, 0, 0, 6);
        addText(form, "Choose a username for your Renio profile.", 13, MUTED, false, 0, 0, 0, 18);
        EditText usernameInput = new EditText(this);
        usernameInput.setSingleLine(true);
        usernameInput.setTextColor(TEXT);
        usernameInput.setHintTextColor(MUTED);
        usernameInput.setHint("Your username");
        usernameInput.setTextSize(15);
        usernameInput.setPadding(dp(15), 0, dp(15), 0);
        usernameInput.setBackground(round(PANEL_2, 14, LINE, 1));
        form.addView(usernameInput, params(-1, 52, 0, 0, 0, 0));
        TextView continueBtn = button("Continue", ACCENT, BG);
        form.addView(continueBtn, params(-1, 52, 0, 14, 0, 0));
        continueBtn.setOnClickListener(v -> {
            String value = usernameInput.getText().toString().trim().replace(" ", "");
            if (value.length() < 3) {
                usernameInput.setError("Use at least 3 characters");
                return;
            }
            if (!value.matches("[A-Za-z0-9_]{3,20}")) {
                usernameInput.setError("Use letters, numbers, or underscores (3–20 characters)");
                return;
            }
            username = value;
            prefs.edit().putString("username", username).apply();
            hideKeyboard(usernameInput);
            showHome("chats");
        });
        TextView privacy = text("No phone number or email required.\nThis starter stores your profile on this device only.", 12, MUTED, false);
        privacy.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams privacyLp = new LinearLayout.LayoutParams(-1, -2);
        privacyLp.topMargin = dp(18);
        form.addView(privacy, privacyLp);

        TextView footer = text("A fresh way to stay connected", 12, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(26);
        root.addView(footer, footerLp);
        setContentView(root);
    }

    private void showHome(String tab) {
        activeTab = tab;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(20), dp(12), dp(20), dp(12));
        TextView mark = text("R", 18, BG, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(circle(ACCENT));
        top.addView(mark, params(38, 38, 0, 0, 11, 0));
        LinearLayout brandBox = new LinearLayout(this);
        brandBox.setOrientation(LinearLayout.VERTICAL);
        brandBox.addView(text("Renio", 18, TEXT, true));
        brandBox.addView(text("YOUR SPACE", 9, MUTED, true));
        top.addView(brandBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView profile = text(initials(username), 13, BG, true);
        profile.setGravity(Gravity.CENTER);
        profile.setBackground(circle(ACCENT));
        top.addView(profile, params(38, 38));
        profile.setOnClickListener(v -> showHome("profile"));
        root.addView(top, params(-1, 62));
        root.addView(line(), params(-1, 1));

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(20), dp(20), dp(24));
        scroller.addView(page);
        root.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1));

        switch (tab) {
            case "files": buildFilesPage(page); break;
            case "gallery": buildGalleryPage(page); break;
            case "profile": buildProfilePage(page); break;
            default: buildChatsPage(page);
        }
        root.addView(bottomNav(tab), params(-1, 68));
        setContentView(root);
    }

    private void buildChatsPage(LinearLayout page) {
        addText(page, "Messages", 27, TEXT, true, 0, 0, 0, 4);
        addText(page, "Good to see you, @" + username, 13, MUTED, false, 0, 0, 0, 18);

        LinearLayout search = new LinearLayout(this);
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setPadding(dp(15), 0, dp(15), 0);
        search.setBackground(round(PANEL, 14, LINE, 1));
        TextView searchIcon = text("⌕", 23, MUTED, false);
        search.addView(searchIcon, params(30, 48));
        EditText searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(14);
        searchInput.setHint("Search messages or people");
        searchInput.setHintTextColor(MUTED);
        searchInput.setTextColor(TEXT);
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        search.addView(searchInput, new LinearLayout.LayoutParams(0, dp(48), 1));
        page.addView(search, params(-1, 48, 0, 0, 0, 18));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(text("Recent chats", 17, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView newChat = text("＋ New", 13, ACCENT, true);
        titleRow.addView(newChat);
        newChat.setOnClickListener(v -> showNewChatDialog());
        page.addView(titleRow, params(-1, -2, 0, 0, 0, 9));

        for (ChatItem item : demoChats) addChatRow(page, item);
        for (String name : customChatNames()) {
            addChatRow(page, new ChatItem(name, "Tap to open conversation", "new"));
        }

        LinearLayout feature = cardColumn();
        page.addView(feature, params(-1, -2, 0, 18, 0, 0));
        addText(feature, "More than messages", 16, TEXT, true, 0, 0, 0, 5);
        addText(feature, "Keep files, photos and shared links together in one place.", 13, MUTED, false, 0, 0, 0, 13);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        feature.addView(actions, params(-1, 44));
        TextView files = smallAction("Files", "▤");
        TextView gallery = smallAction("Gallery", "▧");
        TextView camera = smallAction("Camera", "◉");
        actions.addView(files, new LinearLayout.LayoutParams(0, -1, 1));
        actions.addView(gallery, new LinearLayout.LayoutParams(0, -1, 1));
        actions.addView(camera, new LinearLayout.LayoutParams(0, -1, 1));
        files.setOnClickListener(v -> showHome("files"));
        gallery.setOnClickListener(v -> showHome("gallery"));
        camera.setOnClickListener(v -> launchCamera());
    }

    private void addChatRow(LinearLayout parent, ChatItem item) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(11), dp(11), dp(11), dp(11));
        row.setBackground(round(PANEL, 16, Color.TRANSPARENT, 0));
        TextView avatar = text(item.initials, 13, BG, true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(circle(avatarColor(item.name)));
        row.addView(avatar, params(46, 46, 0, 0, 12, 0));
        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.addView(text(item.name, 14, TEXT, true));
        details.addView(text(item.preview, 12, MUTED, false), params(-1, -2, 0, 4, 0, 0));
        row.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
        TextView time = text(item.time, 10, MUTED, false);
        row.addView(time);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(7);
        parent.addView(row, lp);
        row.setOnClickListener(v -> openThread(item.name));
    }

    private void buildFilesPage(LinearLayout page) {
        addText(page, "Your files", 27, TEXT, true, 0, 0, 0, 5);
        addText(page, "Pick, organize and share documents from your device.", 13, MUTED, false, 0, 0, 0, 20);
        addPickerCard(page, "Browse files", "Choose a document or any file", "▤", () -> launchPicker("*/*", 201));
        addPickerCard(page, "Share a file", "Pick a file and open the Android share sheet", "↗", () -> launchPicker("*/*", 202));
        addPickerCard(page, "Open gallery", "Choose photos and images", "▧", () -> launchPicker("image/*", 203));
        addText(page, "Recent on this device", 16, TEXT, true, 0, 18, 0, 10);
        if (recentFiles.isEmpty()) {
            LinearLayout empty = cardColumn();
            page.addView(empty, params(-1, -2));
            TextView icon = text("▤", 28, ACCENT, true);
            icon.setGravity(Gravity.CENTER);
            empty.addView(icon, params(-1, 42));
            TextView title = text("Nothing here yet", 14, TEXT, true);
            title.setGravity(Gravity.CENTER);
            empty.addView(title, params(-1, -2, 0, 7, 0, 3));
            TextView hint = text("Files you open will appear in this session.", 12, MUTED, false);
            hint.setGravity(Gravity.CENTER);
            empty.addView(hint);
        } else {
            for (String name : recentFiles) {
                LinearLayout recent = new LinearLayout(this);
                recent.setGravity(Gravity.CENTER_VERTICAL);
                recent.setPadding(dp(13), dp(12), dp(13), dp(12));
                recent.setBackground(round(PANEL, 13, LINE, 1));
                recent.addView(text("▤", 20, ACCENT, true), params(35, 35));
                recent.addView(text(name, 13, TEXT, true), params(0, -2, 10, 0, 0, 0));
                page.addView(recent, params(-1, -2, 0, 0, 0, 8));
            }
        }
    }

    private void buildGalleryPage(LinearLayout page) {
        addText(page, "Gallery", 27, TEXT, true, 0, 0, 0, 5);
        addText(page, "Choose photos and images from your device.", 13, MUTED, false, 0, 0, 0, 20);
        LinearLayout hero = cardColumn();
        page.addView(hero, params(-1, -2));
        TextView icon = text("▧", 38, ACCENT, true);
        icon.setGravity(Gravity.CENTER);
        hero.addView(icon, params(-1, 60));
        addText(hero, "Your moments, together", 17, TEXT, true, 0, 10, 0, 5);
        addText(hero, "Renio can open your Android photo picker without needing broad gallery access.", 12, MUTED, false, 0, 0, 0, 15);
        TextView pick = button("Choose photos", ACCENT, BG);
        hero.addView(pick, params(-1, 48));
        pick.setOnClickListener(v -> launchPicker("image/*", 203));
        TextView camera = outlineButton("Take a photo", TEXT);
        hero.addView(camera, params(-1, 48, 0, 9, 0, 0));
        camera.setOnClickListener(v -> launchCamera());
    }

    private void buildProfilePage(LinearLayout page) {
        addText(page, "Your profile", 27, TEXT, true, 0, 0, 0, 5);
        addText(page, "Manage your Renio identity and links.", 13, MUTED, false, 0, 0, 0, 20);
        LinearLayout profileCard = cardColumn();
        page.addView(profileCard, params(-1, -2));
        LinearLayout profileTop = new LinearLayout(this);
        profileTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView avatar = text(initials(username), 22, BG, true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(circle(ACCENT));
        profileTop.addView(avatar, params(58, 58, 0, 0, 13, 0));
        LinearLayout userBox = new LinearLayout(this);
        userBox.setOrientation(LinearLayout.VERTICAL);
        userBox.addView(text("@" + username, 17, TEXT, true));
        userBox.addView(text("Local profile · this device", 12, MUTED, false), params(-1, -2, 0, 5, 0, 0));
        profileTop.addView(userBox);
        profileCard.addView(profileTop);

        addPickerCard(page, "Share your profile", "Create a Renio custom profile link", "↗", () -> shareProfileLink());
        addPickerCard(page, "Create a share link", "Make a custom link from a message", "⌁", () -> showShareTextDialog());
        addPickerCard(page, "About Renio", "A new space for chats and sharing", "ⓘ", () -> showAbout());
        TextView signOut = outlineButton("Sign out on this device", TEXT);
        page.addView(signOut, params(-1, 48, 0, 16, 0, 0));
        signOut.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Sign out?")
            .setMessage("Your local profile will be removed from this device. Demo chat data is not synced.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Sign out", (d, w) -> {
                prefs.edit().remove("username").apply();
                username = "";
                showLogin();
            }).show());
    }

    private void addPickerCard(LinearLayout parent, String title, String subtitle, String iconText, Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(13), dp(14), dp(13));
        row.setBackground(round(PANEL, 15, LINE, 1));
        TextView icon = text(iconText, 21, ACCENT, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(PANEL_2, 12, Color.TRANSPARENT, 0));
        row.addView(icon, params(43, 43, 0, 0, 12, 0));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text(title, 14, TEXT, true));
        labels.addView(text(subtitle, 11, MUTED, false), params(-1, -2, 0, 4, 0, 0));
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(text("›", 24, MUTED, false));
        parent.addView(row, params(-1, -2, 0, 0, 0, 9));
        row.setOnClickListener(v -> action.run());
    }

    private LinearLayout bottomNav(String selected) {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(PANEL);
        nav.setPadding(dp(6), dp(7), dp(6), dp(7));
        nav.addView(navItem("chats", "◌", "Chats", selected), new LinearLayout.LayoutParams(0, -1, 1));
        nav.addView(navItem("files", "▤", "Files", selected), new LinearLayout.LayoutParams(0, -1, 1));
        nav.addView(navItem("gallery", "▧", "Gallery", selected), new LinearLayout.LayoutParams(0, -1, 1));
        nav.addView(navItem("profile", "◎", "Profile", selected), new LinearLayout.LayoutParams(0, -1, 1));
        return nav;
    }

    private View navItem(String key, String icon, String label, String selected) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        int color = key.equals(selected) ? ACCENT : MUTED;
        item.addView(text(icon, 21, color, true));
        item.addView(text(label, 10, color, key.equals(selected)), params(-1, -2, 0, 2, 0, 0));
        item.setOnClickListener(v -> showHome(key));
        return item;
    }

    private void openThread(String name) {
        activeChat = name;
        ArrayList<String> history = getMessages(name);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(9), dp(14), dp(9));
        TextView back = text("‹", 31, TEXT, false);
        back.setGravity(Gravity.CENTER);
        top.addView(back, params(42, 44));
        back.setOnClickListener(v -> showHome("chats"));
        TextView avatar = text(initials(name), 12, BG, true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(circle(avatarColor(name)));
        top.addView(avatar, params(38, 38, 0, 0, 10, 0));
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(text(name, 15, TEXT, true));
        heading.addView(text("Renio local chat", 10, MUTED, false), params(-1, -2, 0, 3, 0, 0));
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        TextView share = text("↗", 21, ACCENT, true);
        top.addView(share, params(34, 40));
        share.setOnClickListener(v -> showShareTextDialog());
        root.addView(top, params(-1, 60));
        root.addView(line(), params(-1, 1));

        messageScroll = new ScrollView(this);
        messageList = new TextView(this);
        messageList.setTextColor(TEXT);
        messageList.setTextSize(14);
        messageList.setPadding(dp(15), dp(16), dp(15), dp(16));
        messageList.setLineSpacing(dp(5), 1f);
        messageScroll.addView(messageList);
        root.addView(messageScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        renderMessages(history);

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(11), dp(9), dp(11), dp(9));
        composer.setBackgroundColor(PANEL);
        TextView attach = text("＋", 24, ACCENT, true);
        attach.setGravity(Gravity.CENTER);
        composer.addView(attach, params(38, 45));
        attach.setOnClickListener(v -> showAttachmentOptions());
        messageInput = new EditText(this);
        messageInput.setSingleLine(false);
        messageInput.setMaxLines(4);
        messageInput.setTextSize(14);
        messageInput.setTextColor(TEXT);
        messageInput.setHintTextColor(MUTED);
        messageInput.setHint("Write a message…");
        messageInput.setPadding(dp(13), dp(10), dp(13), dp(10));
        messageInput.setBackground(round(PANEL_2, 22, Color.TRANSPARENT, 0));
        composer.addView(messageInput, new LinearLayout.LayoutParams(0, -2, 1));
        TextView send = text("➤", 19, BG, true);
        send.setGravity(Gravity.CENTER);
        send.setBackground(circle(ACCENT));
        composer.addView(send, params(43, 43, 8, 0, 0, 0));
        send.setOnClickListener(v -> sendMessage());
        root.addView(composer, params(-1, -2));
        setContentView(root);
        messageScroll.post(() -> messageScroll.fullScroll(View.FOCUS_DOWN));
    }

    private ArrayList<String> getMessages(String name) {
        if (!messages.containsKey(name)) {
            ArrayList<String> seed = new ArrayList<>();
            seed.add("Renio\nThis is a local demo conversation. Messages stay on this device.");
            seed.add(name + "\nHey! Welcome to Renio 👋");
            messages.put(name, seed);
        }
        return messages.get(name);
    }

    private void renderMessages(ArrayList<String> history) {
        StringBuilder builder = new StringBuilder();
        for (String entry : history) {
            String[] parts = entry.split("\\n", 2);
            String sender = parts.length > 0 ? parts[0] : "Renio";
            String body = parts.length > 1 ? parts[1] : "";
            builder.append(sender.equals(username) ? "YOU" : sender.toUpperCase(Locale.ROOT))
                .append("\n").append(body).append("\n\n");
        }
        messageList.setText(builder.toString().trim());
    }

    private void sendMessage() {
        if (messageInput == null || activeChat.isEmpty()) return;
        String value = messageInput.getText().toString().trim();
        if (value.isEmpty()) return;
        getMessages(activeChat).add(username + "\n" + value);
        messageInput.setText("");
        renderMessages(getMessages(activeChat));
        messageScroll.post(() -> messageScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void showAttachmentOptions() {
        String[] choices = {"Choose a file", "Choose a photo", "Take a photo", "Create a Renio share link"};
        new AlertDialog.Builder(this).setTitle("Attach to message").setItems(choices, (d, which) -> {
            if (which == 0) launchPicker("*/*", 202);
            else if (which == 1) launchPicker("image/*", 203);
            else if (which == 2) launchCamera();
            else showShareTextDialog();
        }).show();
    }

    private void showNewChatDialog() {
        EditText input = new EditText(this);
        input.setHint("Username or chat name");
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        input.setBackground(round(PANEL_2, 12, LINE, 1));
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(dp(20), dp(6), dp(20), dp(2));
        wrapper.addView(input, params(-1, 50));
        new AlertDialog.Builder(this).setTitle("Start a chat").setView(wrapper)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Open", (d, w) -> {
                String name = input.getText().toString().trim();
                if (name.length() >= 2) openThread(name);
                else toast("Enter at least 2 characters");
            }).show();
    }

    private void launchPicker(String type, int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(type);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            toast("No compatible file picker was found.");
        }
    }

    private void launchCamera() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (camera.resolveActivity(getPackageManager()) == null) {
            toast("No camera app is available on this device.");
            return;
        }
        startActivityForResult(camera, 204);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == 204) {
            Object image = data.getExtras() == null ? null : data.getExtras().get("data");
            if (image instanceof Bitmap) showCameraPreview((Bitmap) image);
            else toast("Photo captured.");
            return;
        }
        Uri uri = data.getData();
        if (uri == null) return;
        lastPickedUri = uri;
        String name = displayName(uri);
        if (!recentFiles.contains(name)) recentFiles.add(0, name);
        if (requestCode == 202) sharePickedFile(uri);
        else {
            toast("Selected: " + name);
            if (activeChat != null && !activeChat.isEmpty()) {
                getMessages(activeChat).add(username + "\nSelected a file: " + name);
                if (messageList != null) renderMessages(getMessages(activeChat));
            }
            if (activeTab.equals("files")) showHome("files");
        }
    }

    private String displayName(Uri uri) {
        String result = "Selected item";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result;
    }

    private void sharePickedFile(Uri uri) {
        String type = getContentResolver().getType(uri);
        if (type == null) type = "application/octet-stream";
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(type);
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.setClipData(ClipData.newUri(getContentResolver(), "Renio attachment", uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, "Share with"));
    }

    private void showCameraPreview(Bitmap bitmap) {
        ImageView image = new ImageView(this);
        image.setImageBitmap(bitmap);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        new AlertDialog.Builder(this).setTitle("Photo captured")
            .setView(image)
            .setPositiveButton("Done", (d, w) -> { })
            .setNeutralButton("Share", (d, w) -> shareRenioLink("I captured a photo with Renio."))
            .show();
    }

    private void shareProfileLink() {
        Uri link = new Uri.Builder().scheme("renio").authority("profile").appendPath(username).build();
        sharePlainText("Find me on Renio: @" + username + "\n" + link);
    }

    private void showShareTextDialog() {
        EditText input = new EditText(this);
        input.setHint("Write something to share…");
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setMinLines(2);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        input.setBackground(round(PANEL_2, 12, LINE, 1));
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(5), dp(20), 0);
        wrap.addView(input, params(-1, -2));
        new AlertDialog.Builder(this).setTitle("Create a Renio link").setView(wrap)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Share link", (d, w) -> {
                String value = input.getText().toString().trim();
                if (!value.isEmpty()) shareRenioLink(value);
                else toast("Write something first.");
            }).show();
    }

    private void shareRenioLink(String value) {
        Uri link = new Uri.Builder().scheme("renio").authority("share").appendQueryParameter("text", value).build();
        sharePlainText(value + "\n\nOpen in Renio: " + link);
    }

    private void sharePlainText(String content) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, content);
        startActivity(Intent.createChooser(send, "Share with"));
    }

    private void showAbout() {
        new AlertDialog.Builder(this).setTitle("About RenioAPP")
            .setMessage("Renio is an original messaging and sharing app starter. This build includes a local-only profile, demo chats, device file/photo pickers, camera handoff and renio:// custom links.\n\nOnline accounts, live messaging, calls, cloud storage and public web links require a backend and a domain.")
            .setPositiveButton("OK", null).show();
    }

    private ArrayList<String> customChatNames() {
        ArrayList<String> names = new ArrayList<>();
        for (String key : messages.keySet()) {
            boolean known = false;
            for (ChatItem item : demoChats) if (item.name.equals(key)) known = true;
            if (!known) names.add(key);
        }
        return names;
    }

    private TextView smallAction(String label, String icon) {
        TextView view = text(icon + "  " + label, 11, ACCENT, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(round(PANEL_2, 10, Color.TRANSPARENT, 0));
        return view;
    }

    private LinearLayout cardColumn() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(round(PANEL, 17, LINE, 1));
        return card;
    }

    private TextView button(String label, int background, int foreground) {
        TextView view = text(label, 14, foreground, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(round(background, 14, Color.TRANSPARENT, 0));
        return view;
    }

    private TextView outlineButton(String label, int foreground) {
        TextView view = text(label, 13, foreground, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(round(PANEL, 14, LINE, 1));
        return view;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void addText(LinearLayout parent, String value, int size, int color, boolean bold,
                         int left, int top, int right, int bottom) {
        TextView view = text(value, size, color, bold);
        parent.addView(view, params(-1, -2, left, top, right, bottom));
    }

    private View line() {
        View view = new View(this);
        view.setBackgroundColor(LINE);
        return view;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (strokeWidth > 0) drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setShape(GradientDrawable.OVAL);
        return drawable;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
    }

    private LinearLayout.LayoutParams params(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = params(width, height);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private void add(LinearLayout parent, View view, int width, int height) {
        parent.addView(view, params(width, height));
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String initials(String name) {
        if (name == null || name.trim().isEmpty()) return "R";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase(Locale.ROOT);
        return (parts[0].substring(0, 1) + parts[1].substring(0, 1)).toUpperCase(Locale.ROOT);
    }

    private int avatarColor(String value) {
        int[] colors = {0xFF80CBC4, 0xFFFFC078, 0xFF9EA8DA, 0xFFFF9EAB, 0xFF81B8F8};
        return colors[Math.abs(value.hashCode()) % colors.length];
    }

    private void hideKeyboard(View view) {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } catch (Exception ignored) { }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
