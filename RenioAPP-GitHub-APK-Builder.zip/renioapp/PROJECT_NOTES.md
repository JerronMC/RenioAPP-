# RenioAPP implementation notes

## Current screens
- Username onboarding
- Chats and local conversation view
- Files picker and share flow
- Gallery picker
- Camera launch and thumbnail preview
- Profile and custom-link sharing

## Local link formats
- `renio://share?text=...`
- `renio://profile/<username>`

The Android manifest registers the `renio` scheme. These links are app deep links, not web-hosted links. To make public URLs, deploy a service and configure verified Android App Links for a domain you own.

## Current persistence
The display username is stored in `SharedPreferences`. Chat messages are held in memory for the current process only. There is no server, database, end-to-end encryption, online account, or message synchronization in this starter.

## Suggested service interfaces for a later backend
- `POST /v1/accounts` — create account and issue an authenticated session
- `GET /v1/chats` — list authorized chats
- `GET /v1/chats/{chatId}/messages` — paginated message history
- `POST /v1/chats/{chatId}/messages` — send a message
- `POST /v1/uploads` — request an access-controlled upload URL
- `GET /v1/shares/{shareId}` — resolve an expiring or public share token

Do not expose service secrets in the Android app. Enforce authorization, upload limits, rate limits, account controls, and moderation on the server.
