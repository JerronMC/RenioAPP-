# RenioAPP — Android starter

RenioAPP is an original, mobile-first messaging and file-sharing app starter. It takes broad inspiration from the convenience of modern messengers, but uses its own name, visual style, layout, and `renio://` link scheme.

## What is included

- Username-only first-run profile. There is no phone-number or email field.
- Chats list and local demo conversation screen with a message composer.
- Start-a-chat flow using a display name / username.
- Files screen using Android's document picker.
- Gallery screen using Android's image picker.
- Camera handoff to the camera app, with an in-app preview of the returned thumbnail.
- Android share sheet for files and text.
- Custom `renio://share?text=...` and `renio://profile/<username>` links.
- Dark, mobile-first Renio interface and bottom navigation.
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Important: starter build, not a live messenger yet

This ZIP is a **source project**. GitHub Actions compiles the APK; it does not create a live messaging service.

The current app is a local UI prototype:

- The username is saved only on the current device. It is not a registered online account and is not protected by a server-side login.
- The sample conversations are demo data. Messages typed into the app stay in the current app session and are not delivered to another user.
- File/photo selection and Android share-sheet handoff are device features. Cloud upload and synced file storage are not implemented.
- `renio://` links are app deep links. They work when Renio is installed on the receiving device and the link is opened by Android. The profile link currently opens a local informational toast; it does not look up a remote user.
- Public links such as `https://renio.app/...` require a domain, a web endpoint, Android App Links verification (`/.well-known/assetlinks.json`), and a service that stores/retrieves shared content.

Do not use this prototype to send sensitive information. It does not implement end-to-end encryption, server authentication, abuse reporting, or production data protection.

## Build the APK with GitHub Actions

1. Create a new GitHub repository.
2. Upload the **contents** of this ZIP to the repository root (the `.github` folder must also be uploaded).
3. Set the default branch to `main` or `master`.
4. Open the repository's **Actions** tab.
5. The `Build RenioAPP APK` workflow runs on push and can also be started with **Run workflow**.
6. Open the completed workflow run. Under **Artifacts**, download `RenioAPP-debug-apk`.
7. Extract the artifact ZIP to get `app-debug.apk`.

The build workflow uses JDK 17, Android SDK platform 36, Android Build Tools 36.0.0, Android Gradle Plugin 9.5.1, and Gradle 9.6.0. These versions are pinned in the project/workflow for repeatable builds.

## Build locally

Open the project root in a recent Android Studio installation. Let Android Studio install Android SDK Platform 36 and Build Tools 36.0.0 if prompted. Run the `app` configuration, or run this from a terminal where Gradle 9.6.0 and JDK 17 are installed:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Package details

- App name: `RenioAPP`
- Application ID: `com.renio.app`
- Minimum Android version: Android 8.0 (API 26)
- Target SDK: API 36
- Language: Java
- UI: native Android views; no third-party UI framework

## Next production milestones

1. Choose a backend (for example, your own API or a managed database/auth provider).
2. Implement secure username registration, session management, and account recovery. A username-only screen is not secure authentication by itself.
3. Add realtime message delivery, online status, push notifications, message history, and server-side authorization.
4. Add private cloud file storage with size/type limits and access-controlled download links.
5. Move share payloads to a backend and configure a real HTTPS domain plus Android App Links.
6. Add block/report tools, rate limits, moderation, privacy controls, and a tested encryption design before public release.

## License

This starter is provided under the MIT License. See `LICENSE`.
